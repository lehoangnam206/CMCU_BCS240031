namespace VnNewsApp.Models
{
    public class Article
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Summary { get; set; } = string.Empty;
        public string ImageUrl { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public string Author { get; set; } = string.Empty;
        public int CommentCount { get; set; }
        public string TimeAgo { get; set; } = string.Empty;
        public bool IsFeatured { get; set; }
    }
}
